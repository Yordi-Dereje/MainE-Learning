// For Demo Purpose [Changing input group text on focus]
$(function () {
    $('input, select').on('focus', function () {
        $(this).parent().find('.input-group-text').css('border-color', '#80bdff');
    });
    $('input, select').on('blur', function () {
        $(this).parent().find('.input-group-text').css('border-color', '#ced4da');
    });
});
function handleCredentialResponse(response) {
    var responsePayload = response.credential;
    // Send the ID token to your server for verification or use
    console.log('ID token: ' + responsePayload);
}